package com.albar.moviecatalogue.data.source.remote.api

interface ApiService {
    @GET("")

}