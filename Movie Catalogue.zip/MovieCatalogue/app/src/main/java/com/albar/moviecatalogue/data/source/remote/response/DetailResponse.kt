package com.albar.moviecatalogue.data.source.remote.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DetailResponse(
    var id: String,
    var poster: String,
    var title: String,
    var popularity: String,
    var releaseData: String
) : Parcelable
